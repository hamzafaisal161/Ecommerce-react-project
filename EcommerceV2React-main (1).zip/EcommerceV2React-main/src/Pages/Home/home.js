import './home.css'
import React from 'react'
const HomeBody = () => {
  return (
    <div className='home-w'>
      <h2>
        Ecommerce V2
        <br />
      </h2>
      <h4>Made by Hamza Faisal</h4>
    </div>
  )
}

export default HomeBody
